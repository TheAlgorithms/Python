# DC-WGAN
with addded gradient penalty 
